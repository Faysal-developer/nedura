"# nedura" 
